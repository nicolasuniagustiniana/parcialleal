package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btn_siguiente;
    private Button btn_agregar;

    private EditText edit_nombre_uno;
    private EditText edit_apellido_dos;
    public TextView text_Respuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        text_Respuesta=findViewById(R.id.Respuesta);

        edit_nombre_uno = findViewById(R.id.nombre1);
        edit_apellido_dos = findViewById(R.id.nombre2);

        btn_agregar = findViewById(R.id.button_agregar);
        btn_agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text_Respuesta.setText(agregar(Integer.parseInt(edit_nombre_uno.getText().toString()),Integer.parseInt(edit_apellido_dos.getText().toString()))+"");
            }
        });

        btn_siguiente = findViewById(R.id.button_siguiente);
        btn_siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);

            }
        });
    }
    public static double agregar (int a, int b){return a+b;}
}